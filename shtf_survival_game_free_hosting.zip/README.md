# SHTF Decision & Survival Simulator

A free, static browser game. No account, server, subscription, or API key is required.

## Play locally
Open `index.html` in a modern browser. Progress is saved in that browser's local storage.

## Free hosting with GitHub Pages
1. Sign in to GitHub and create a new public repository (for example `shtf-survival-game`).
2. Upload `index.html` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then Save.
6. Wait for GitHub Pages to provide the public website URL.

The game is a fictional educational simulation. Its scores are learning indicators, not real-world survival predictions. Follow official emergency advice and local laws.
